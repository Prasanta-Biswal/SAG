﻿using Microsoft.Extensions.Caching.Memory;
using Station.Search.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Station.Search.Repository
{
    public interface ISearchRepository
    {
        Node GetNode(string forWord);
    }
    public class SearchRepository : ISearchRepository
    {
        private readonly IMemoryCache _cache;
        public SearchRepository(IMemoryCache cache)
        {
            _cache = cache;
            // Seed the test data
            BuildSeedData();
        }

        private Node TopNode_ { get; set; }
        private Node TopNode
        {
            get
            {
                if (TopNode_ == null) TopNode_ = new Node(null, ' ');
                return TopNode_;
            }
        }
        /// <summary>
        /// Total nodes in this trie
        /// </summary>
        public int TotalNodes { get; private set; }

        /// <summary>
        /// Total terminal nodes in this trie
        /// </summary>
        public int TerminalNodes { get; private set; }

        private bool CaseSensitive { get; set; }

        private void BuildSeedData()
        {
            var stationNames = _cache.Get<List<string>>("stationnames");
            if (!(stationNames != null && stationNames.Count > 0))
            {
                stationNames = new List<string>() { "PURI", "BALASORE", "DELHI", "CUTTACT", "YELENKA", "VIZAG", "DARTMON", "BANGALORE", "BANKOK", "KRPURAM", "KRMKT" };

                //created some more test data to test
                for (int i = 0; i <= 100000; i++)
                {
                    stationNames.Add("BAN" + i);
                }
                // In-memory cache
                MemoryCacheEntryOptions cacheExpirationOptions = new MemoryCacheEntryOptions();
                cacheExpirationOptions.AbsoluteExpiration = DateTime.Now.AddMinutes(30);
                cacheExpirationOptions.Priority = CacheItemPriority.Normal;
                _cache.Set<List<string>>("stationnames", stationNames, cacheExpirationOptions);
            }
            AddStation(stationNames);
        }

        private void AddStation(List<string> stationNm)
        {
            foreach (string wrd in stationNm)
            {
                string word = NormaliseWord(wrd);
                var selectedNode = TopNode;

                for (var i = 0; i < word.Length; i++)
                {
                    var c = word[i];
                    if (!selectedNode.Nodes.ContainsKey(c))
                    {
                        selectedNode.Nodes.Add(c, new Node(selectedNode, c));
                        TotalNodes++;
                    }
                    selectedNode = selectedNode.Nodes[c];
                }

                // Already exists
                if (selectedNode.Terminal) return;

                selectedNode.Terminal = true;
                TerminalNodes++;
            }
        }

        /// <summary>
        /// Get the node that starts with forWord
        /// </summary>
        public Node GetNode(string forWord)
        {
            forWord = NormaliseWord(forWord);
            var selectedNode = TopNode;
            foreach (var c in forWord)
            {
                if (!selectedNode.Nodes.ContainsKey(c)) return null;
                selectedNode = selectedNode.Nodes[c];
            }
            return selectedNode;
        }

        /// <summary>
        /// Normalise word for DS
        /// </summary>
        private string NormaliseWord(string word)
        {
            if (String.IsNullOrWhiteSpace(word)) word = String.Empty;
            word = word.Trim();
            if (!CaseSensitive)
            {
                word = word.ToLower();
            }
            return word;
        }
    }
}
