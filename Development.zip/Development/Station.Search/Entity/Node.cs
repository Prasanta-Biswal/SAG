﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Station.Search.Entity
{
    public class Node
    {
        public bool Terminal { get; set; }
        public Dictionary<char, Node> Nodes { get; private set; }
        public Node ParentNode { get; private set; }
        public char C { get; private set; }

        /// <summary>
        /// String word represented by this node
        /// </summary>
        public string Word
        {
            get
            {
                var b = new StringBuilder();
                b.Insert(0, C.ToString(CultureInfo.InvariantCulture));
                var selectedNode = ParentNode;
                while (selectedNode != null)
                {
                    b.Insert(0, selectedNode.C.ToString(CultureInfo.InvariantCulture));
                    selectedNode = selectedNode.ParentNode;
                }
                return b.ToString();
            }
        }

        public Node(Node parent, char c)
        {
            C = c;
            ParentNode = parent;
            Terminal = false;
            Nodes = new Dictionary<char, Node>();
        }

        /// <summary>
        /// Return list of terminal nodes under this node
        /// </summary>
        public IEnumerable<Node> TerminalNodes(char? ignoreChar = null)
        {
            var r = new List<Node>();
            if (Terminal) r.Add(this);
            foreach (var node in Nodes.Values)
            {
                if (ignoreChar != null && node.C == ignoreChar) continue;
                r = r.Concat(node.TerminalNodes()).ToList();
            }
            return r;
        }
    }
}
