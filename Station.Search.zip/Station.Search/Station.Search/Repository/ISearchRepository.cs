﻿using Microsoft.Extensions.Caching.Memory;
using Station.Search.DataSource;
using Station.Search.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Station.Search.Repository
{
    public interface ISearchRepository
    {
        Node GetNode(string forWord);
    }
    public class SearchRepository : ISearchRepository
    {
        private readonly StationTree _stationTree;

        public SearchRepository(StationTree stationTree)
        {
            _stationTree = stationTree;
        }
        
        /// <summary>
        /// Get the node that starts with forWord
        /// </summary>
        public Node GetNode(string forWord)
        {
            forWord = NormaliseWord(forWord);
            var selectedNode = _stationTree.TopNode;
            foreach (var c in forWord)
            {
                if (!selectedNode.Nodes.ContainsKey(c)) return null;
                selectedNode = selectedNode.Nodes[c];
            }
            return selectedNode;
        }

        /// <summary>
        /// Normalise word for trie
        /// </summary>
        private string NormaliseWord(string word)
        {
            if (String.IsNullOrWhiteSpace(word)) word = String.Empty;
            return word.Trim().ToLower();
        }

        
    }
}
