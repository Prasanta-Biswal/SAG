﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Station.Search.DataSource
{    

    public class InMemoryDataSource : IDataSource
    {
        private readonly IMemoryCache _cache;
        public InMemoryDataSource(IMemoryCache cache) {
            _cache = cache;
        }
        public List<string> GetStationNames()
        {
            var stationNames = _cache.Get<List<string>>("stationnames");
            if (!(stationNames != null && stationNames.Count > 0))
            {
                stationNames = new List<string>() { "PURI", "BALASORE", "DELHI", "CUTTACT", "YELENKA", "VIZAG", "DARTMON", "BANGALORE", "BANKOK", "KRPURAM", "KRMKT" };
                for (int i = 0; i <= 100000; i++)
                {
                    stationNames.Add("BAN" + i);
                }
                MemoryCacheEntryOptions cacheExpirationOptions = new MemoryCacheEntryOptions();
                cacheExpirationOptions.AbsoluteExpiration = DateTime.Now.AddMinutes(30);
                cacheExpirationOptions.Priority = CacheItemPriority.Normal;
                _cache.Set<List<string>>("stationnames", stationNames, cacheExpirationOptions);
            }
            return stationNames;
        }
    }
}
