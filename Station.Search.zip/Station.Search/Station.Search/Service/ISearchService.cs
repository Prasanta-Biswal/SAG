﻿using Microsoft.Extensions.Caching.Memory;
using Station.Search.Entity;
using Station.Search.Model;
using Station.Search.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Station.Search.Service
{
    public interface ISearchService
    {
        SearchResponse GetAutocompleteSuggestions(string startingWord, int fetchMax = 100);
    }

    public class SearchService : ISearchService
    {

        private readonly ISearchRepository _searchRepository;

        public SearchService(ISearchRepository searchRepository)
        {
            _searchRepository = searchRepository;
        }


        /// <summary>
        /// Get list of all words in trie that start with
        /// </summary>
        public SearchResponse GetAutocompleteSuggestions(string startingWord, int fetchMax = 100)
        {
            SearchResponse searchResponse = new SearchResponse();

            //if (fetchMax <= 0) throw new Exception("Fetch max must be positive integer.");

            var result = new HashSet<string>();

            var foundNode = _searchRepository.GetNode(startingWord);
            if (!(foundNode != null && foundNode.Nodes != null && foundNode.Nodes.Count > 0)) return null;

            // Get terminal nodes for this node

            var terminalNodes = foundNode.TerminalNodes().Take(fetchMax);
            foreach (var node in terminalNodes)
            {
                result.Add(node.Word.Trim());
            }

            searchResponse.StationNames = result;
            searchResponse.NextCharacters = new List<char>();
            if (result.Count() > 0)
            {
                foreach (var s in result)
                {
                    // get the next character 
                    int Index = s.IndexOf(startingWord);
                    //get the next character only if next char is available
                    if (s.Length > startingWord.Length)
                    {
                        Char nextChar = s[Index + startingWord.Length];
                        if (!searchResponse.NextCharacters.Contains(nextChar))
                        {
                            searchResponse.NextCharacters.Add(nextChar);
                        }
                    }
                }
            }
            return searchResponse;
        }

    }
}
