﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Station.Search.Model;
using Station.Search.Service;

namespace Station.Search.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {
        private readonly ISearchService _searchService;
        public SearchController(ISearchService searchService) {
            _searchService = searchService;
        }
        [HttpGet]
        [Route("{startingWord}")]
        public IActionResult Get(string startingWord )
        {
            var searchResponse = _searchService.GetAutocompleteSuggestions(startingWord);
            if (searchResponse == null)
            {
                return NotFound("No Station Found");
            }
            return Ok(searchResponse);
        }
        
    }
}
