﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Station.Search.Entity
{

    public class StationTree
    {
        private Node TopNode_ { get; set; }
        public Node TopNode
        {
            get
            {
                if (TopNode_ == null) TopNode_ = new Node(null, ' ');
                return TopNode_;
            }
        }
        /// <summary>
        /// Total nodes in this trie
        /// </summary>
        public int TotalNodes { get; set; }

        /// <summary>
        /// Total terminal nodes in this trie
        /// </summary>
        public int TerminalNodes { get; set; }

        public void BuildStationTree(List<string> words)
        {
            if (words != null && words.Any())
            {
                foreach (string wrd in words)
                {
                    string word = NormaliseWord(wrd);
                    var selectedNode = TopNode;

                    for (var i = 0; i < word.Length; i++)
                    {
                        var c = word[i];
                        if (!selectedNode.Nodes.ContainsKey(c))
                        {
                            selectedNode.Nodes.Add(c, new Node(selectedNode, c));
                            TotalNodes++;
                        }
                        selectedNode = selectedNode.Nodes[c];
                    }

                    // Already exists
                    if (selectedNode.Terminal) return;

                    selectedNode.Terminal = true;
                    TerminalNodes++;
                }
            }

        }

        private string NormaliseWord(string word)
        {
            if (String.IsNullOrWhiteSpace(word)) word = String.Empty;
            return word.Trim().ToLower();
        }
    }

    public class Node
    {
        public bool Terminal { get; set; }
        public Dictionary<char, Node> Nodes { get; private set; }
        public Node ParentNode { get; private set; }
        public char C { get; private set; }

        /// <summary>
        /// String word represented by this node
        /// </summary>
        public string Word
        {
            get
            {
                var b = new StringBuilder();
                b.Insert(0, C.ToString(CultureInfo.InvariantCulture));
                var selectedNode = ParentNode;
                while (selectedNode != null)
                {
                    b.Insert(0, selectedNode.C.ToString(CultureInfo.InvariantCulture));
                    selectedNode = selectedNode.ParentNode;
                }
                return b.ToString();
            }
        }

        public Node(Node parent, char c)
        {
            C = c;
            ParentNode = parent;
            Terminal = false;
            Nodes = new Dictionary<char, Node>();
        }

        /// <summary>
        /// Return list of terminal nodes under this node
        /// </summary>
        public IEnumerable<Node> TerminalNodes(char? ignoreChar = null)
        {
            var r = new List<Node>();
            if (Terminal) r.Add(this);
            foreach (var node in Nodes.Values)
            {
                if (ignoreChar != null && node.C == ignoreChar) continue;
                r = r.Concat(node.TerminalNodes()).ToList();
            }
            return r;
        }
    }
}
