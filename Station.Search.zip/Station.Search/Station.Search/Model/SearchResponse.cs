﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Station.Search.Model
{
    public class SearchResponse
    {
        public HashSet<string> StationNames { get; set; }
        public List<char> NextCharacters { get; set; }
    }
}
