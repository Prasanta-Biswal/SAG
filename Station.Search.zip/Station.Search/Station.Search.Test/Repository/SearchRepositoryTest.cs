﻿using Xunit;
using Moq;
using System.Threading.Tasks;
using System.Collections.Generic;
using Station.Search.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Collections;
using Station.Search.Entity;
using Station.Search.Repository;

namespace Station.Search.Test.Repository
{
    public class SearchRepositoryTest
    {
        private SearchRepository RepositoryUnderTest { get; set; }

        public SearchRepositoryTest()
        {

        }

        [Theory]
        [MemberData(nameof(GetStationListFromDataGenerator))]
        public void Test_GetNode_Should_Return_SelectedNode(string startingWord, List<string> stations, int expectedTerminalNode)
        {
            var stationTree = new StationTree();
            stationTree.BuildStationTree(stations);
            RepositoryUnderTest = new SearchRepository(stationTree);
            var result = RepositoryUnderTest.GetNode(startingWord);

            Assert.True(result != null && result.Nodes.Any() && result.TerminalNodes().Count() == expectedTerminalNode);

        }
        public static IEnumerable<object[]> GetStationListFromDataGenerator()
        {
            var allData = new List<object[]>
            {
                new object[]
                 {
                     "ban",new  List<string>() {  "Ban1", "Ban2" }, 2
                }
            };
            return allData;
        }
    }
}
