﻿using Station.Search.Controllers;
using Station.Search.Service;
using Xunit;
using Moq;
using System.Threading.Tasks;
using System.Collections.Generic;
using Station.Search.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Collections;
using Station.Search.Entity;

namespace Station.Search.Test.Controller
{
    public class SearchControllerTest
    {
        protected SearchController ControllerUnderTest { get; }
        protected Mock<ISearchService> mockSearchService { get; }

        public SearchControllerTest()
        {
            mockSearchService = new Mock<ISearchService>();
            ControllerUnderTest = new SearchController(mockSearchService.Object);
        }

        [Theory]
        [MemberData(nameof(GetStationListFromDataGenerator))]
        public void Test_Get_Should_Return_Ok(string startWith , SearchResponse searchResponse)
        {
            mockSearchService.Setup(p => p.GetAutocompleteSuggestions(It.IsAny<string>(), It.IsAny<int>())).
                Returns(searchResponse);
            var result = ControllerUnderTest.Get(startWith);
            var expectedResult = Assert.IsType<OkObjectResult>(result);

            var searchResponseModel = expectedResult.Value as SearchResponse;
            Assert.True(searchResponseModel?.NextCharacters != null && searchResponse.NextCharacters.Count() == searchResponseModel.NextCharacters.Count() &&
               searchResponseModel?.StationNames != null && searchResponse.StationNames.Count() == searchResponseModel.StationNames.Count());
        }

       [Fact]
        public void Test_Get_Should_Return_NotFound()
        {
            mockSearchService.Setup(p => p.GetAutocompleteSuggestions(It.IsAny<string>(), It.IsAny<int>())).
                Returns(default(SearchResponse));
            var result = ControllerUnderTest.Get(It.IsAny<string>());
            var expectedResult = Assert.IsType<NotFoundObjectResult>(result);
        }

        public static IEnumerable<object[]> GetStationListFromDataGenerator()
        {
            var allData = new List<object[]>
            {
                new object[]
                 {
                     "be",new SearchResponse { StationNames = new HashSet<string>() { "Bengaluru", "Bellary" },
                            NextCharacters = new List<char>() { 'n', 'l' }}                    
                },
                new object[]{
                    "bh",new SearchResponse { StationNames = new HashSet<string>() { "Bhubaneswar", "Bhopal" },
                            NextCharacters = new List<char>() { 'u', 'o' }}                    
                },
                new object[]{
                    "ba",new SearchResponse { StationNames = new HashSet<string>() { "Balasore", "Banli" },
                            NextCharacters = new List<char>() { 'l', 'n' }}
                }

            };
            return allData;
        }

    }

}
